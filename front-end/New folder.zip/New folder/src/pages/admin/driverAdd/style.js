export const styleSheet={
    driver_id:{

        },


}