import React from "react";
import Login from "../pages/customer/login";
import CarAdd from "../pages/admin/carAdd/carAdd";
import CarView from "../pages/admin/carView/vehicleView";
import DriverAdd from "../pages/admin/driverAdd/driver";
import AddCustomer from "../pages/customer/customerAdd/addCustomer";

function App() {
  return (
      <CarAdd/>
  );
}

export default App;
