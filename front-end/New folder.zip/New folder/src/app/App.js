import React from "react";
import Login from "../pages/customer/login";
import CarAdd from "../pages/admin/carAdd/carAdd";

function App() {
  return (
      <CarAdd/>
  );
}

export default App;
